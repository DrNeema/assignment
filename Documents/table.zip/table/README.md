# Time-table
Class Timetable for 2024/2025

This project recreates a weekly school timetable using HTML and CSS. The timetable is organized into 7 periods from 6:00 AM to 4:30 PM with distinct days for Monday to Saturday. The Morning-preps, breaks and lunch periods are highlighted.

Included files:
- table.html: The main HTML file for the timetable layout.
- table.css: CSS stylesheet for styling the timetable.
- timetable_preview.png: Screenshot of the rendered timetable.

